/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/

#library("WiiGestures");
#import('dart:html');

class WiiGestures {
WebSocket ws=null;
Function onGesture;

int wx=0,wy=0,wz=0,wb=0;
int owx,owy,owz,oldb,relax=0,maxrelax=0;

WiiGestures() {
  ws = new WebSocket('ws://127.0.0.1:40001');
  ws.on.open.add((evt) { ws.send("Hello"); });
  ws.on.message.add(this.onMessage);
  //ws.on.close.add((evt) { });
  //ws.on.error.add((evt) { }); 
  this.onGesture=(a){};
  maxrelax=1*Clock.frequency();
}

void onMessage(evt) {
  String a=evt.data;
  var b=a.split('|');
  this.updateBy(Math.parseInt(b[0]),Math.parseInt(b[1]),Math.parseInt(b[2]),Math.parseInt(b[5]));
  ws.send("0");
}

void updateBy(int a,int b,int c,int d){
  owx=wx; owy=wy; owz=wz;
  wx=a*0.1+wx*0.9;
  wy=b*0.1+wy*0.9;
  wz=c*0.1+wz*0.9;
  if(oldb!=d) this.onGesture(d.toString());
  oldb=d;
  
  if((Clock.now()-relax)<maxrelax) return;
  if(wx>5300){
    this.onGesture('next');
    relax=Clock.now();
    return;
  }
  if(wx<4200){
    this.onGesture('prev');
    relax=Clock.now();
    return;
  }
  if(wz>5600 && wz<5750){
    this.onGesture('go');
    relax=Clock.now();
    return;
  }
  if(wz<4200){
    this.onGesture('back');
    relax=Clock.now();
    return;
  }
  
}

}

/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/
