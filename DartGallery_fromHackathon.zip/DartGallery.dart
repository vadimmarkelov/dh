/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/

#import('dart:html');
#import('MultimediaWorker.dart');
#import('WiiGestures.dart');

List mas;
var cur = 0;
var Wii; 

void main() {
  Wii= new WiiGestures();
  Wii.onGesture=(a){
    ImageElement x;
    switch(a){
      case "next":
        nextImg();
        break;
      case "prev":
        prevImg();
        break;
      case "go":
        x=document.query('#img'+(cur).toString());
        x.classes.clear();
        x.classes.add('curimage2');
        break;
      case "back":
        x=document.query('#img'+(cur).toString());
        x.classes.clear();
        x.classes.add('curimage');
        break;
    }
  };
  
  MultimediaWorker mw = new MultimediaWorker();
  mas = mw.requestMedia();
  
  for(var i=0; i<mas.length; i++)
    if(i<3) AddI(i,1); else AddI(i,0);  
  cur=1;
  window.setTimeout( () {
    ShowImage(cur);
  },1000);
  
}

void AddI(int a, int b){
  ImageElement x= new Element.html('<img id="img'+a+'" src="'+mas[a]+'" class="imagenone" />');
  document.query("#images").nodes.add(x);
  if(b==1)
    window.setTimeout( () {
        x.classes.clear();
        x.classes.add('image');
      },100); 
}

void ShowImage(int a){
  ImageElement x;
  if(a>1){
    x=document.query('#img'+(a-2).toString());
    x.classes.clear();
    x.classes.add('imagenone');
  }
  if(a>0){
    x=document.query('#img'+(a-1).toString());
    x.classes.clear();
    x.classes.add('image');
  }
    x=document.query('#img'+(a.toString()));
    x.classes.clear();
    x.classes.add('curimage');
  
  if(a<(mas.length-1)){
    x=document.query('#img'+(a+1).toString());
    x.classes.clear();
    x.classes.add('image');
  }
  if(a<(mas.length-2)){
    x=document.query('#img'+(a+2).toString());
    x.classes.clear();
    x.classes.add('imagenone');
  }
}

void nextImg(){
  {
    cur++;cur=(cur < mas.length)?cur:(mas.length-1);
    ShowImage(cur);
   }
}

void prevImg(){
  {
    cur--; cur=(cur>=0)?cur:0;
    ShowImage(cur);
    }
}

/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/
