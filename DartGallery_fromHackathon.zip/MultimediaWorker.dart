/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/

#library("MultimediaWorker");

#import("dart:html");
#import("dart:json");
#import("dart:core");

class MultimediaWorker {
  
  List requestMedia() {
    final req = new XMLHttpRequest();
    req.open('GET', 'pictures.txt', false);
    req.send();
    return req.responseText.split('\n'); 
  }
  
}

/*
DartVaider team // Dartlang hackathon at Lviv,Ukraine http://lviv.gdg.org.ua/2012/05/15/darthack-lviv/

Vadim Markelov https://plus.google.com/114182430074405515342
Roman Lytvyn https://plus.google.com/110790864966808015880
Vova Miniof https://plus.google.com/116139335995910178752
*/
